package com.ticketsbooking.BusTicketBookingsApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BusTicketBookingsApplicationTests {

	@Test
	void contextLoads() {
	}

}
