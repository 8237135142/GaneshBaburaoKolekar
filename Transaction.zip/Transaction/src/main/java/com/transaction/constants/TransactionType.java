package com.transaction.constants;

public enum TransactionType {
	
	DEBIT,CREDIT;

}
