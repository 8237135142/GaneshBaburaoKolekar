package com.transaction.dto;

import lombok.Data;
@Data
public class UserDTO {

	private int userId;

	private String username;

	private String password;

	private String phoneNo;

	private String email;

}
