package com.gk.exception;

public class UserNotFoundException extends Exception {

	public UserNotFoundException(String string) {
		// TODO Auto-generated constructor stub
	}

}
