# CMPE275CUSR
CMPE 275 Team Project - Train Ticket Reservation System


# TOOLS
Spring Boot

Spring Security

Spring MVC

Spring DATA

JPA

Firebase

MySQL

Thymeleaf

Bootstrap

Eclipse/STS

Maven

Java 8
