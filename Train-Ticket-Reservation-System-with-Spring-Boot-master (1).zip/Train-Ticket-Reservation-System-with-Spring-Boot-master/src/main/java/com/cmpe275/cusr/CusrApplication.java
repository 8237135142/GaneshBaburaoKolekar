package com.cmpe275.cusr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CusrApplication {

	public static void main(String[] args) {
		SpringApplication.run(CusrApplication.class, args);
	}
}
