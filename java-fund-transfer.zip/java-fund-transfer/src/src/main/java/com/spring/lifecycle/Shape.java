package com.spring.lifecycle;

public interface Shape {
	public void drawShape();

}
