package com.spring.lifecycle;

public class Point {

}
