package com.spring.lifecycle;

public class Cricle {

}
