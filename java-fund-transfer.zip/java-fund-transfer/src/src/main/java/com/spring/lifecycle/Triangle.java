package com.spring.lifecycle;

public class Triangle implements Shape {

	@Override
	public void drawShape() {

	}

}
