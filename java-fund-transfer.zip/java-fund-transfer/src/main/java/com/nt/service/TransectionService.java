package com.nt.service;

import java.util.List;

import com.nt.dto.TransectionDTO;

public interface TransectionService {

	List<TransectionDTO> fatchTransection();

}
