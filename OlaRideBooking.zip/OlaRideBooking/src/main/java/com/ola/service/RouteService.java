package com.ola.service;

import java.util.List;

import com.ola.model.Route;

public interface RouteService {

	public List<Route> getRoutes();
}
