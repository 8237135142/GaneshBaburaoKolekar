package com.ola.service;

import com.ola.model.Ride;

public interface RideService {
	
	public void BookRide(Ride ride);

	public Object getRide();

}

