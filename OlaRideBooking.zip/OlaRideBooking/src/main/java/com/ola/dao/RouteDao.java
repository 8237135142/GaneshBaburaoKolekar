package com.ola.dao;

import java.util.List;

import com.ola.model.Route;

public interface RouteDao {

	public List<Route> getRoutes();
}
