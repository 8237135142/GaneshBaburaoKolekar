package com.booking.Train_Ticket_Booking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainTicketBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
