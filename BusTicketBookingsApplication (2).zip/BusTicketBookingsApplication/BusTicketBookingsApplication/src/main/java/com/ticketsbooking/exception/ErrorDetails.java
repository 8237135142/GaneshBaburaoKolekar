package com.ticketsbooking.exception;



public class ErrorDetails {
	
	 private String message;
	
	 public ErrorDetails(String message){
		 super();
		 this.message = message;
	 }
	
	 public String getMessage() {
	        return message;
	   }
	
	
	
	
   // private Date timestamp;
   
   // private String details;

   /* public ErrorDetails(Date timestamp, String message, String details) {
        super();
        this.timestamp = timestamp;
        this.message = message;
        this.details = details;
    }*/

   /* public Date getTimestamp() {
        return timestamp;
    }*/

    
/*
    public String getDetails() {
       return details;
   }*/
}
