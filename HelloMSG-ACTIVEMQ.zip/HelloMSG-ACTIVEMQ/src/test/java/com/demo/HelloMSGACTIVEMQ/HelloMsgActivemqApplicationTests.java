package com.demo.HelloMSGACTIVEMQ;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloMsgActivemqApplicationTests {

	@Test
	void contextLoads() {
	}

}
