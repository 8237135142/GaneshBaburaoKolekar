package com.demo.HelloMSGACTIVEMQ;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloMsgActivemqApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelloMsgActivemqApplication.class, args);
	}

}
